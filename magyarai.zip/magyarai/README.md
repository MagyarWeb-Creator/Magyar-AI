# MagyarAI 🤖🇭🇺

Egy vagány magyar AI chatbot — Discord bothoz, Robloxhoz, programozáshoz és mindenhez ért. Nem nyalja a seggedet.

## Fájl struktúra

```
magyarai/
├── index.html                  # A chatbot frontend
├── netlify.toml                # Netlify konfig
├── netlify/
│   └── functions/
│       └── chat.js             # Szerver oldali Claude API hívás
└── README.md
```

## Deploy lépések

### 1. GitHub repo létrehozása
1. Menj a [github.com](https://github.com) oldalra
2. Kattints a **"New repository"** gombra
3. Add meg a nevet (pl. `magyarai`)
4. Kattints **"Create repository"**-ra
5. Töltsd fel a fájlokat (drag & drop vagy git push)

### 2. Netlify összekötés
1. Menj a [netlify.com](https://netlify.com) oldalra és regisztrálj (ingyenes)
2. Kattints **"Add new site"** → **"Import an existing project"**
3. Válaszd a **GitHub**-ot
4. Válaszd ki a repódat (`magyarai`)
5. Build settings — hagyd üresen, a `netlify.toml` mindent beállít
6. Kattints **"Deploy site"**-ra

### 3. API kulcs beállítása (FONTOS!)
1. A Netlify dashboardon menj: **Site settings** → **Environment variables**
2. Kattints **"Add a variable"**-ra
3. Key: `ANTHROPIC_API_KEY`
4. Value: a saját Claude API kulcsod (https://console.anthropic.com)
5. Mentés, majd **Redeploy**

### 4. Kész! 🎉
Az oldalad elérhető lesz a Netlify által adott URL-en (pl. `magyarai.netlify.app`)

## API kulcs szerzése
1. Menj: https://console.anthropic.com
2. Regisztrálj / lépj be
3. **API Keys** → **Create Key**
4. Másold ki és tedd be a Netlify environment variable-be

## Fontos tudnivalók
- Az API kulcs **biztonságos** — a szerver oldalon van, nem látják a látogatók
- Netlify Functions **125,000 ingyenes hívás/hó** — bőven elég
- Claude API-nak van költsége, de az első időszakban van free credit
