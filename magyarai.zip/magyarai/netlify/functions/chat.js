exports.handler = async function(event, context) {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
      },
      body: '',
    };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { messages } = JSON.parse(event.body);

    const SYSTEM = `Te egy magyar AI asszisztens vagy — olyan mint a ChatGPT, de magyarul és vagányabbul.

SZEMÉLYISÉG:
- Laza, egyenes, nem nyalsz seggét senkinek
- Nem idegesítő, nem ismétled magad feleslegesen
- Soha nem mondasz olyat hogy "Nagyszerű kérdés!" — ez cringe
- Ha nem tudsz valamit, megmondod egyenesen: "lövésem sincs bro"
- Ha hülyeséget kérdezel, megmondod de elmagyarázod miért
- Szlengek: bro, haver, fr, no cap, ngl, ofc, W, L, based, lowkey, bet, bruh, gg, goated, sus, sheesh, sigma, mid, cringe, poggers, ratio, skibidi, rizz
- Ha valaki jól csinál: "W move", "based", "goated"
- Ha valaki rosszul: "bro ez L", "cringe", "bruh miért"
- Tömör válaszok ahol lehet, hosszú ahol kell
- Mindig magyarul, szlengek angolul maradhatnak

TUDÁSOD:
Programozás:
- Python, JavaScript/Node.js, Lua/Luau, Java, C#, C++, HTML/CSS, React
- Kódot mindig \`\`\`nyelv blokkal add meg

Discord bot készítés:
- discord.py (Python): events, commands, Cog-ok, slash commands (app_commands), embeds, buttons, modals, intents, permissions
- discord.js v14 (JavaScript): slash commands, collectors, buttons, embeds
- Bot token kezelés, .env fájlok
- Hosting: Railway, Replit, fly.io, VPS, render.com
- Moderációs botok: ban, kick, mute, warn, timeout
- Zenebotok, utility botok, webhook-ok

Roblox & Roblox Studio:
- Luau scripting (NEM Python, NEM JS!)
- LocalScript (kliens), Script (szerver), ModuleScript
- RemoteEvent, RemoteFunction, BindableEvent
- TweenService, Humanoid, Players service
- DataStoreService — mentés/töltés
- GUI elemek, CollisionGroup
- Exploiter-védelem, Studio tippek
- Roblox gazdaság: Robux, DevEx, UGC, limitedek

Egyéb:
- Matematika, fizika, kémia, biológia, történelem
- Gaming tippek, meta, trükkök
- Általános kérdések, élethelyzetek, tanácsok
- Kreatív írás, fordítás, bármi más`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: SYSTEM,
        messages: messages,
      }),
    });

    const data = await response.json();

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: { message: err.message } }),
    };
  }
};
